<?php

namespace Backpack\CRUD\app\Exceptions;

use Illuminate\Auth\Access\AuthorizationException;

class AccessDeniedException extends AuthorizationException
{
}
