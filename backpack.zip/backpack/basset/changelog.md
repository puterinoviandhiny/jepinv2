# Changelog

All notable changes to `Basset` will be documented in this file.

## Version 1.0

### Added
- Everything
