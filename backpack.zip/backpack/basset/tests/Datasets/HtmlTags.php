<?php

dataset('htmlTags', [
    'script' => [
        'bootstrap/js/bootstrap.min.js',
        'script',
    ],
    'link' => [
        'bootstrap/css/bootstrap.min.css',
        'link',
    ],
]);
