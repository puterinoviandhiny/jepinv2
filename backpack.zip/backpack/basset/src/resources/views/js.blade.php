<script src="{{ $src }}" {!! $args !!}></script>
