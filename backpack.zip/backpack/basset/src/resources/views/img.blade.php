<img src="{{ $src }}"{!! $args !!} />
