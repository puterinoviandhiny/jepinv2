<object data="{{ $src }}"{!! $args !!}>
    <p>Unable to display file. <a href="{{ $src }}" target="_blank">Download</a> instead.</p>
</object>
