<link rel="icon" type="image/x-icon" href="{{ $src }}"{!! $args !!} />
